package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Response;
import com.example.demo.model.Song;
import com.example.demo.service.SongService;

@RestController
public class SongController {

	@Autowired
	SongService songService;
	
	@PostMapping("/registerSong")
	public Object registerSong(@RequestBody Song song) {
		Object result = songService.addSong(song);
		if(result == null) {
			return new ResponseEntity<>(new Response("failed"), HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(new Response(result), HttpStatus.OK);
	}
	
	@PostMapping("/deleteSong")
	public Object deleteSong(@RequestBody Song song) {
		Object result = songService.deleteSongById(song.getId());
		if(result == null) {
			return new ResponseEntity<>(new Response("failed"), HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(new Response(result), HttpStatus.OK);
	}
	
	@PostMapping("/updateSong")
	public Object updateSong(@RequestBody Song song) {
		Object result = songService.updateSong(song);
		if(!(result instanceof Song)) {
			return new ResponseEntity<>(new Response(result), HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(new Response(result), HttpStatus.OK);
	}
	
	@GetMapping("/getSongById")
	public Object getSongById(@RequestParam Long id) {
		Object result = songService.getSongById(id);
		if(!(result instanceof Song)) {
			return new ResponseEntity<>(new Response(result), HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(new Response(result), HttpStatus.OK);		
	}
	
	@GetMapping("/getAllSongs")
	public Object getAllSongs(@RequestParam String sortBy, @RequestParam String orderBy) {
		Object result = songService.getAllSongs(orderBy, sortBy);
		if(result instanceof String) {
			return new ResponseEntity<>(new Response(result), HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(new Response(result), HttpStatus.OK);
	}
	
	@GetMapping("/getAllSongsByCategoryId")
	public Object getAllSongsByCategoryId(@RequestParam Long categoryId) {
		Object result = songService.getAllSongsByCategoryId(categoryId);
		if(result instanceof String) {
			return new ResponseEntity<>(new Response(result), HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(new Response(result), HttpStatus.OK);
	}
	
	@GetMapping("/getTop3SongsByViews")
	public Object getTop3SongsByViews() {
		Object result = songService.getTop3SongsByViews();
		if(result instanceof String) {
			return new ResponseEntity<>(new Response(result), HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(new Response(result), HttpStatus.OK);
	}
	
}
