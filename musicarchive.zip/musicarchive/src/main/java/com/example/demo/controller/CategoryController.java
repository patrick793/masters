package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Category;
import com.example.demo.model.Response;
import com.example.demo.model.Song;
import com.example.demo.service.CategoryService;

@RestController
public class CategoryController {
	
	@Autowired
	CategoryService categoryService;
		
	@PostMapping("/addCategory")
	public Object addCategory(@RequestBody Category category) {
		Object result = categoryService.addCategory(category);
		if(result == null) {
			return new ResponseEntity<>(new Response("failed"), HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(new Response(result), HttpStatus.NOT_FOUND);
	}
	
	@GetMapping("/getAllCategories")
	public Object getAllCategories() {
		Object categories = categoryService.getAllCategories();		
		if(categories == null) {
			return new ResponseEntity<>(new Response("failed"), HttpStatus.NOT_FOUND); 
		}
		return new ResponseEntity<>(new Response(categories), HttpStatus.OK);
	}
	
	@GetMapping("/getCategoryById")
	public Object getSongById(@RequestParam Long id) {
		Object result = categoryService.getCategoryById(id);
		if(result == null) {
			return new ResponseEntity<>(new Response("no category found"), HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(new Response(result), HttpStatus.OK);		
	}
	
	@PostMapping("/updateCategory")
	public Object updateCategory(@RequestBody Category category) {
		Object result = categoryService.updateCategory(category);				
		if(result == null) {
			return new ResponseEntity<>(new Response("failed"), HttpStatus.NOT_FOUND); 
		}		
		return new ResponseEntity<>(new Response(result), HttpStatus.OK);
	}
	
	@PostMapping("/deleteCategoryById")
	public Object deleteCategoryById(@RequestBody Category category) {
		Object result = categoryService.deleteCategoryById(category.getId());
		if(result == null) {
			return new ResponseEntity<>(new Response("failed"), HttpStatus.NOT_FOUND);
		}		
		return new ResponseEntity<>(new Response(result), HttpStatus.OK);		
	}
	
}
