package com.example.demo.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Song;

public interface SongRepository extends CrudRepository<Song, Long>{

	List<Song> findByOrderByTitleDesc();
	List<Song> findByOrderByArtistDesc();
	List<Song> findByOrderByLengthDesc();
	List<Song> findByOrderByViewsDesc();
	
	List<Song> findByOrderByTitle();
	List<Song> findByOrderByArtist();
	List<Song> findByOrderByLength();
	List<Song> findByOrderByViews();
	
	List<Song> findByCategoryId(Long id);
	
	List<Song> findTop3ByOrderByViewsDesc();
}
