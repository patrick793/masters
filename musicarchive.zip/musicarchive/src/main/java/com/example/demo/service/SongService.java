package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Category;
import com.example.demo.model.Song;
import com.example.demo.repository.CategoryRepository;
import com.example.demo.repository.SongRepository;

@Service
public class SongService {

	@Autowired
	SongRepository songRepository;
	
	@Autowired
	CategoryRepository categoryRepository;
	
	public Object addSong(Song song) {
		Category foundCategory = categoryRepository.findById(song.getCategory().getId()).orElse(null);
		if(foundCategory == null) {
			return null;
		}
		return songRepository.save(song);
	}
	
	public Object deleteSongById(Long id) {
		Song foundSong = songRepository.findById(id).orElse(null);
		if(foundSong == null) {
			return "no song found!";
		}
		songRepository.deleteById(id);
		return "song deleted successfully!";
			
	}
	
	public Object updateSong(Song song) {
		Song foundSong = songRepository.findById(song.getId()).orElse(null);
		if(foundSong == null) {
			return "no song found!";
		}		
		Category foundCategory = categoryRepository.findById(song.getCategory().getId()).orElse(null);
		if(foundCategory == null) {
			return "no category found!";
		}	
		return songRepository.save(song);
	}
	
	public Object getSongById(Long id) {
		Song song = songRepository.findById(id).orElse(null);
		if(song == null) {
			return "no song found!";
		}
		return song;		
	}
	
	public Object getAllSongs (String orderBy, String sortBy) {
		Object result = null;
		if(sortBy.equals("title")) {
			if(orderBy.equals("desc")) {
				result = songRepository.findByOrderByTitleDesc();
			} else {
				result = songRepository.findByOrderByTitle();
			}
		}
		else if(sortBy.equals("artist")) {
			if(orderBy.equals("desc")) {
				result = songRepository.findByOrderByArtistDesc();
			} else {
				result = songRepository.findByOrderByArtist();
			}
		}
		else if(sortBy.equals("views")) {
			if(orderBy.equals("desc")) {
				result = songRepository.findByOrderByViewsDesc();
			} else {
				result = songRepository.findByOrderByViews();
			}
		}
		
		if(result == null) {
			return "no songs found!";
		}
		return result;
	}
	
	public Object getAllSongsByCategoryId(Long categoryId) {
		Category foundCategory = categoryRepository.findById(categoryId).orElse(null);
		if(foundCategory == null) {
			return "no category found!";
		}
		Object result = songRepository.findByCategoryId(categoryId);
		if(result == null) {
			return "no songs found!";
		}
		return result;
	}
	
	public Object getTop3SongsByViews() {
		Object result = songRepository.findTop3ByOrderByViewsDesc();
		if(result == null) {
			return "no songs found!";
		}
		return result;
	}
	
}
