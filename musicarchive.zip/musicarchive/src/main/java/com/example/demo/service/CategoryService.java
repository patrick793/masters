package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Category;
import com.example.demo.repository.CategoryRepository;

@Service
public class CategoryService {
	
	@Autowired
	CategoryRepository categoryRepository;
	
	public Object addCategory(Category category) {
		return categoryRepository.save(category);
	}
	
	public Object getAllCategories() {
		return categoryRepository.findAll();
	}	
	
	public Object updateCategory(Category category) {
		Category foundCategory = getCategoryById(category.getId());
		if(foundCategory == null) {
			return "no category found!";
		}
		return categoryRepository.save(category);
	}
	
	
	public Object sortAndGetFirstTwoCategories() {
		return categoryRepository.findTop2ByOrderByNameDesc();
	}
	
	
	public Object deleteCategoryById(Long id) {
		Category category = getCategoryById(id);
		if(category == null) {
			return "no category found!";
		}
		categoryRepository.deleteById(id);
		if(getCategoryById(id) == null) {
			return "category deleted successfully!";
		}
		return null;		
	}
	
	public Category getCategoryById(Long id) {
		Category foundCategory = categoryRepository.findById(id).orElse(null);
		return foundCategory;
	}
}
